from tkinter import *
import math

root = Tk()
root.title("Scientific Calculator")            # sets the name on the top of the gui
root.configure(background = 'white')
root.resizable(width=False, height=False)
root.geometry("944x568+0+0")
calc = Frame(root)
calc.grid()

txtDisplay = Entry(calc, font=('Helvetica',20,'bold'),
				bg='black',fg='white',
				bd=30,width=56,justify=RIGHT)
txtDisplay.grid(row=0,column=0, columnspan=8, pady=1)


def click(to_print):
    old=txtDisplay.get()
    txtDisplay.delete(0 , END)
    txtDisplay.insert(0 , old+to_print)
    return


def clear():
    txtDisplay.delete(0 , END)
    return

def display(value):
        txtDisplay.delete(0, END)
        txtDisplay.insert(0, value)

def ln():
        current = math.ln(float(txtDisplay.get()))
        display(current)

def log():
        current = math.log10(float(txtDisplay.get()))
        display(current)

def cos():
        current = math.cos(math.radians(float(txtDisplay.get())))
        display(current)
def acos():
        current = math.acos(math.radians(float(txtDisplay.get())))
        display(current)
  
def tan():
        current = math.tan(math.radians(float(txtDisplay.get())))
        display(current)
  
def atan():
        current = math.atan(math.radians(float(txtDisplay.get())))
        display(current)
  
def sin():
        current = math.sin(math.radians(float(txtDisplay.get())))
        display(current)
  
def asin():
        current = math.asin(math.radians(float(txtDisplay.get())))
        display(current)
def exp():
        current = math.exp(float(txtDisplay.get()))
        display(current)
def fact():
        current = math.factorial(int(txtDisplay.get()))
        display(current)
def abs():
    current=math.fabs(float(txtDisplay.get()))
    display(current)
def ceil():
    current=math.ceil(float(txtDisplay.get()))
    display(current)

def  floor():
    current=math.floor(float(txtDisplay.get()))
    display(current)

def  sqrt():
    current=math.sqrt(float(txtDisplay.get()))
    display(current)

def  pi():
    current=math.pi
    display(current)

def evaluate():
    ans=txtDisplay.get()
    ans=eval(ans)
    txtDisplay.delete(0 , END)
    txtDisplay.insert(0 , ans)

btn_ln = Button(calc, text="ln",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:ln()).grid(
    row=1, column=0, pady=1)

btn_log = Button(calc, text="Log",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:log()).grid(
    row=1, column=1,  pady=1)
btn_ = Button(calc, text="(",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("(")).grid(
    row=1, column=2,  pady=1)

btn_ = Button(calc, text=")",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click(")")).grid(
    row=1, column=3,  pady=1)
btnclr = Button(calc, text=chr(67),
                  width=12, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: clear()).grid(
    row=1, column=4,columnspan=2,  pady=1)

btnAdd = Button(calc, text="+",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("+")).grid(
    row=1, column=6,  pady=1)
btn_sqrt = Button(calc, text="\u221A",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: sqrt()).grid(
    row=1, column=7,  pady=1)
#2nd row

btn_sin = Button(calc, text="sin",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:sin()).grid(
    row=2, column=0,  pady=1)

btn_cos = Button(calc, text="cos",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:cos()).grid(
    row=2, column=1,  pady=1)

btn_tan = Button(calc, text="tan",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:tan()).grid(
    row=2, column=2,  pady=1)

btn_7= Button(calc, text="7",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("7")).grid(
    row=2, column=3,  pady=1)

btn_8= Button(calc, text="8",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("8")).grid(
    row=2, column=4,  pady=1)

btn_9= Button(calc, text="9",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("9")).grid(
    row=2, column=5,  pady=1)

btn_sub= Button(calc, text="-",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("-")).grid(
    row=2, column=6,  pady=1)

btn_mod= Button(calc, text="%",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("%")).grid(
    row=2, column=7,  pady=1)
#3rd row
btn_asin= Button(calc, text="asin",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:asin()).grid(
    row=3, column=0,  pady=1)

btn_acos= Button(calc, text="acos",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:acos()).grid(
    row=3, column=1,  pady=1)

btn_atan= Button(calc, text="atan",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:atan()).grid(
    row=3, column=2,  pady=1)

btn_4= Button(calc, text="4",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: click("4")).grid(
    row=3, column=3,  pady=1)

btn_5= Button(calc, text="5",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: click("5")).grid(
    row=3, column=4,  pady=1)

btn_6= Button(calc, text="6",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: click("6")).grid(
    row=3, column=5,  pady=1)

btn_div= Button(calc, text="/",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("/")).grid(
    row=3, column=6,  pady=1)

btn_floor_div= Button(calc, text="//",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("//")).grid(
    row=3, column=7,  pady=1)
#4th row
btn_factorial= Button(calc, text="X!",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:fact()).grid(
    row=4, column=0,  pady=1)

btn_exp= Button(calc, text="exp",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:exp()).grid(
    row=4, column=1,  pady=1)

btn_Abs= Button(calc, text="Abs",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:abs()).grid(
    row=4, column=2,  pady=1)

btn_1= Button(calc, text="1",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: click("1")).grid(
    row=4, column=3,  pady=1)

btn_2= Button(calc, text="2",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: click("2")).grid(
    row=4, column=4,  pady=1)

btn_3= Button(calc, text="3",
                  width=6, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: click("3")).grid(
    row=4, column=5,  pady=1)

btn_mul= Button(calc, text="*",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("*")).grid(
    row=4, column=6,  pady=1)

btn_power= Button(calc, text="**",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("**")).grid(
    row=4, column=7,  pady=1)

#5th row
btn_ceil= Button(calc, text="ceil",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda: ceil()).grid(
    row=5, column=0,  pady=1)

btn_floor= Button(calc, text="floor",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:floor()).grid(
    row=5, column=1,  pady=1)

btn_pi= Button(calc, text="pi",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:pi()).grid(
    row=5, column=2,  pady=1)

btn_zero= Button(calc, text="0",
                  width=12, height=2,
                  bg='blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click("0")).grid(
    row=5, column=3, columnspan=2, pady=1)

btn_dot= Button(calc, text=".",
                  width=6, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:click(".")).grid(
    row=5, column=5,  pady=1)

btn_equal= Button(calc, text="=",
                  width=12, height=2,
                  bg='powder blue',
                  font=('Helvetica', 20, 'bold'),
                  bd=4,
                  command=lambda:evaluate()).grid(
    row=5, column=6, columnspan=2, pady=1)

		



root.mainloop()